package com.jupitertoys.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.jupitertoys.base.TestBase;

public class JupiterToysShopPage extends TestBase {



	@FindBy(xpath = "//li[@id='product-2']//a[@class='btn btn-success'][normalize-space()='Buy']")
	static WebElement StuffedFrog;

	@FindBy(xpath = "//li[@id='product-4']//a[@class='btn btn-success'][normalize-space()='Buy']")
	static WebElement FluffyBunny;

	@FindBy(xpath = "//li[@id='product-7']//a[@class='btn btn-success'][normalize-space()='Buy']")
	static WebElement ValentineBear;
	
	@FindBy(xpath="//a[@href='#/cart']")
	static WebElement cartLink;
	
	@FindBy(xpath="//a[normalize-space()='Check Out']")
	static WebElement checkoutLink;
	
	

	public JupiterToysShopPage() {
		PageFactory.initElements(driver, this);
	}



	public void AddStuffedFrog() {
		try {

			int a = 0;
			// iterate 3 times and click element
			while (a < 2) {
				a++;
				// click add to cart element
				StuffedFrog.click();
				
			}
			System.out.println("Stuffed Frog Product added");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void AddFluffyBunny() {
		try {

			int b = 0;
			// iterate 3 times and click element
			while (b < 5) {
				b++;
				// click add to cart element
				FluffyBunny.click();
				
			}
			System.out.println("Fluffy Bunny Product added");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void AddValentineBear() {
		try {

			int c = 0;
			// iterate 3 times and click element
			while (c < 3) {
				c++;
				// click add to cart element
				ValentineBear.click();
				
			}
			System.out.println("Valentine Bear Product added");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	//Below method is to verify StuffedFrog Actual Price
	public void StuffedFrogPriceCheck(){
		
		String StuffedFrogPrice = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[1]/td[2]")).getText();
		String StuffedFrogQty = driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/form[1]/table[1]/tbody[1]/tr[1]/td[3]/input[1]")).getText();

		double StuffedFrogPriceInDoub= Double.parseDouble(StuffedFrogPrice);
		double StuffedFrogQtyInDoub= Double.parseDouble(StuffedFrogQty);
		
		double StuffedFrogExpPrice = StuffedFrogPriceInDoub * StuffedFrogQtyInDoub;
		System.out.println(StuffedFrogExpPrice);
		
		
		String StuffedFrogActualPrice = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[1]/td[4]")).getText();
		if (StuffedFrogActualPrice.equals(StuffedFrogExpPrice)) {
			System.out.println("Actual Price is " + StuffedFrogExpPrice);
			Assert.assertEquals(StuffedFrogActualPrice, StuffedFrogExpPrice);

		}
	}


	//Below method is to verify FluffyBunny Actual Price
	public void FluffyBunnyPriceCheck(){
		
		String FluffyBunnyPrice = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[2]/td[2]")).getText();
		String FluffyBunnyQty = driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/form[1]/table[1]/tbody[1]/tr[2]/td[3]/input[1]")).getText();

		double FluffyBunnyPriceInDoub= Double.parseDouble(FluffyBunnyPrice);
		double FluffyBunnyQtyInDoub= Double.parseDouble(FluffyBunnyQty);
		
		double FluffyBunnyExpPrice = FluffyBunnyPriceInDoub * FluffyBunnyQtyInDoub;
		System.out.println(FluffyBunnyExpPrice);
		
		
		String FluffyBunnyActualPrice = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[2]/td[4]")).getText();
		if (FluffyBunnyActualPrice.equals(FluffyBunnyExpPrice)) {
			System.out.println("Actual Price is " + FluffyBunnyExpPrice);
			Assert.assertEquals(FluffyBunnyActualPrice, FluffyBunnyExpPrice);

		}
	}

	
	//Below method is to verify ValentineBear Actual Price
	public void ValentineBearPriceCheck(){
		
		String ValentineBearPrice = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[3]/td[2]")).getText();
		String ValentineBearQty = driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/form[1]/table[1]/tbody[1]/tr[3]/td[3]/input[1]")).getText();

		double ValentineBearPriceInDoub= Double.parseDouble(ValentineBearPrice);
		double ValentineBearQtyInDoub= Double.parseDouble(ValentineBearQty);
		
		double ValentineBearExpPrice = ValentineBearPriceInDoub * ValentineBearQtyInDoub;
		System.out.println(ValentineBearExpPrice);
		
		
		String ValentineBearActualPrice = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[3]/td[4]")).getText();
		if (ValentineBearActualPrice.equals(ValentineBearExpPrice)) {
			System.out.println("Actual Price is " + ValentineBearExpPrice);
			Assert.assertEquals(ValentineBearActualPrice, ValentineBearExpPrice);

		}
	}

	
		public void validateItems() {
			try {
				driver.findElement(By.xpath("//a[normalize-space()='Check Out']")).click();
				System.out.println("Clicked on Checkout Button");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String actualCheckoutmsg = driver.findElement(By.xpath("//div[@class='alert alert-success']")).getText();
			System.out.println("Checkout page success message");
			String expectedCheckoutMsg="Almost there - your 10 items are nearly in your hands.";
		//	String expectedSuccessMsg="we appreciate your feedback.";
			
			if (actualCheckoutmsg.contains(expectedCheckoutMsg)) {
				System.out.println("Data is successfully submitted with success message as:" + actualCheckoutmsg);

				Assert.assertEquals(actualCheckoutmsg, expectedCheckoutMsg);

			}

		}


	
	public void JupiterToysClickCartLink() {
		cartLink.click();
		
	}
		
	//clicking on Checkout button on Shop page	
	public void JupiterToysCheckoutLink() {
		checkoutLink.click();
		}
		

}

