package com.jupitertoys.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.jupitertoys.*;
import com.jupitertoys.base.TestBase;

public class JupiterToysHomePage extends TestBase{
	
	
	
	@FindBy(xpath="//a[contains(@href,'#/contact')]")
	static WebElement contactPageLink;
	
	@FindBy(xpath = "//a[normalize-space()='Shop']")
	static WebElement ShopPageLink;
	
	public JupiterToysHomePage(){
		PageFactory.initElements(driver, this);
	}
	
	public static String validateJupiterToysHomePage(){
		return driver.getTitle();
	}
	
	public void JupiterToysClickContactLink() {
		contactPageLink.click();
	}	
	public void JupiterToysClickShopLink() {
			ShopPageLink.click();
		}
}
		
	
		
	
