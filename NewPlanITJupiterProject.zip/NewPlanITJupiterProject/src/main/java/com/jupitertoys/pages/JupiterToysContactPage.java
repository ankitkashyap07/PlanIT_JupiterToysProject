package com.jupitertoys.pages;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.jupitertoys.base.TestBase;
import com.jupitertoys.*;

public class JupiterToysContactPage extends TestBase {

	//validate Jupiter page logo
	@FindBy(xpath = "//a[@class='brand']")
	static WebElement jupiterLogo;

	// validate contact page header message
	@FindBy(xpath = "//div[@class='alert alert-info ng-scope']")
	static public String contactPageHeaderMessage;

	
	//contact page fields validation
	@FindBy(xpath = "//input[@id='forename']")
	static String forename;

	@FindBy(xpath = "//input[@id='surname']")
	static WebElement surname;

	@FindBy(xpath = "//input[@id='email']")
	static WebElement email;
	
	@FindBy(xpath = "//input[@id='telephone']")
	static String telephone;

	@FindBy(xpath = "//textarea[@id='message']")
	static WebElement message;

	@FindBy(xpath = "//a[@class='btn-contact btn btn-primary']")
	static String submitButton;
	
	@FindBy(xpath = "//div[@class='alert alert-success']")
	static String successMessage;
	
	//contact page mandatory fields error validation
	@FindBy(xpath = "//span[@id='forename-err']")
	static String forenameError;

	@FindBy(xpath = "//span[@id='email-err']")
	static String emailError;

	@FindBy(xpath = "//span[@id='message-err']")
	static String messageError;
	
	ThreadLocal<String> name=new ThreadLocal<String>();

	

	public static boolean validateContactPageLogo() {
		return jupiterLogo.isDisplayed();
	}

	//comparing contact page header message for successful validation that we are on contact page
	public void  validateContactTitle() {
		try {
			System.out.println("abc");
			String expectedMessage = "We welcome your feedback - tell it how it is.";
			String actualMessage = driver.findElement(By.xpath("//div[@class='alert alert-info ng-scope']")).getText();
			Assert.assertEquals(expectedMessage,actualMessage);
			System.out.println("ContactPage is verified");
		} catch (Exception e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}

	

	//clicking on Submit button with the proper details
	public void ClickSubmit() {
		try {
			driver.findElement(By.xpath("//a[@class='btn-contact btn btn-primary']")).click();
			System.out.println("Clicked on Submit Button");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void FillContactInformation() {

		
		driver.findElement(By.xpath("//input[@id='forename']")).sendKeys("JupiterToys");
		String firstname =driver.findElement(By.xpath("//input[@id='forename']")).getText();
		name.set(firstname);
		System.out.println(firstname);
		
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("abc@abc.com");
		driver.findElement(By.xpath("//textarea[@id='message']")).sendKeys("Testing Jupiter Toys");

		return;
	}

	public void VerifyForenameErrorMessages() {
		String actualForenameMsg = driver.findElement(
				By.xpath("//span[@id='forename-err']")).getText();
		String expectedForenameMsg="Forename is required";

		if (actualForenameMsg.equals(expectedForenameMsg)) {
			System.out.println("Forename error message is  " +actualForenameMsg);
			System.out.println("Forename error message verified");
			Assert.assertEquals(actualForenameMsg, expectedForenameMsg);

		}
	}

	public void VerifyEmailErrorMessages() {
		String actualEmaileMsg = driver.findElement(
				By.xpath("//span[@id='email-err']")).getText();
		String expectedemailMsg="Email is required";
		if (actualEmaileMsg.equals(expectedemailMsg)) {
			System.out.println("Email error message is " + actualEmaileMsg);
			System.out.println("Email error message verified");
			Assert.assertEquals(expectedemailMsg, actualEmaileMsg);

		}
	}

	public void VerifyErrorMessages() {
		String actualErrorMsg = driver.findElement(
				By.xpath("//span[@id='message-err']")).getText();
		String expectedErrorMsg="Message is required";
		if (actualErrorMsg.equals(expectedErrorMsg)) {
			System.out.println("error message is " + actualErrorMsg);
			Assert.assertEquals(actualErrorMsg, expectedErrorMsg);

		}
	}
		
		public void VerifySuccessMessageOnSubmit() {
			

//			String	NameEntered=name.get();
//			System.out.println(NameEntered);
			String actualSuccessMsg = driver.findElement(By.xpath("//div[@class='alert alert-success']")).getText();
			System.out.println("Contact page success message");
			String expectedSuccessMsg="Thanks JupiterToys, we appreciate your feedback.";
		//	String expectedSuccessMsg="we appreciate your feedback.";
			
			if (actualSuccessMsg.contains(expectedSuccessMsg)) {
				System.out.println("Data is successfully submitted with success message as:" + actualSuccessMsg);

				Assert.assertEquals(actualSuccessMsg, expectedSuccessMsg);

			}

	}

}
