package com.testbasics.testcases;

import org.testng.annotations.Test;

public class Testlogin {
	
	@Test
	public void test(){
		System.out.println("Abc");
	}

}
