package com.jupitertoys.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jupitertoys.*;
import com.jupitertoys.base.TestBase;
import com.jupitertoys.pages.JupiterToysHomePage;
import com.jupitertoys.pages.JupiterToysContactPage;
import com.jupitertoys.pages.JupiterToysShopPage;

public class JupiterToysTestCase extends TestBase {
	JupiterToysHomePage jupiterToysHomePage;
	JupiterToysContactPage jupiterToysContactPage;
	JupiterToysShopPage jupiterToysShopPage;

	public JupiterToysTestCase() {
		super();
	}

	@BeforeMethod
	public void setUp() {
		initialization();
		jupiterToysHomePage = new JupiterToysHomePage();
		jupiterToysContactPage = new JupiterToysContactPage();
		jupiterToysShopPage =new JupiterToysShopPage();

	}

	@Test(priority = 1)
	public void TestCase1() {

		/**
		 * Test case1:Part 1: Verifying error message after clicking on submit
		 */

		try {
			String title = JupiterToysHomePage.validateJupiterToysHomePage();
			org.testng.Assert.assertEquals(title, "Jupiter Toys");

			// driver.findElement(By.xpath("//a[contains(@href,'#/contact')]")).click();

			Thread.sleep(5000);

			jupiterToysHomePage.JupiterToysClickContactLink();

			jupiterToysContactPage.validateContactTitle();
			jupiterToysContactPage.ClickSubmit();

			jupiterToysContactPage.VerifyForenameErrorMessages();
			jupiterToysContactPage.VerifyEmailErrorMessages();
			jupiterToysContactPage.VerifyErrorMessages();

			/**
			 * Test case 1:Part 2:Populating all the field with data and
			 * submitting.
			 *
			 */

			jupiterToysContactPage.FillContactInformation();
			jupiterToysContactPage.ClickSubmit();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	 @Test(priority=2, invocationCount=5)
	 public void TestCase2() {
	
	 /**
	 * Test case2:Populating all the mandatory field with data and verify it
	 * is submitted.
	 */
	
	 try {
		String title = JupiterToysHomePage.validateJupiterToysHomePage();
		 org.testng.Assert.assertEquals(title, "Jupiter Toys");
		 jupiterToysHomePage.JupiterToysClickContactLink();
		
		 // jupiterToysContactPage.validateContactTitle();
		 jupiterToysContactPage.FillContactInformation();
		 jupiterToysContactPage.ClickSubmit();
		 jupiterToysContactPage.VerifySuccessMessageOnSubmit();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	 }
	
	
	 @Test(priority=3)
	 public void TestCase3() {
	
	 /**
	 * Test case3: Adding products to the cart and verifying the count.
	 */
	
	 try {
		
		 jupiterToysHomePage.JupiterToysClickShopLink();
		 jupiterToysShopPage.AddStuffedFrog();
		 jupiterToysShopPage.AddFluffyBunny();
		 jupiterToysShopPage.AddValentineBear();
		 
		 jupiterToysShopPage.JupiterToysClickCartLink();
	//	 jupiterToysShopPage.validateItems();
		 jupiterToysShopPage.StuffedFrogPriceCheck();
		 jupiterToysShopPage.FluffyBunnyPriceCheck();
		 jupiterToysShopPage.ValentineBearPriceCheck();
		 jupiterToysShopPage.JupiterToysCheckoutLink();
		

	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	 }
	

//	@AfterMethod
//	public void tearDown() {
//		driver.close();
//		driver.quit();
//	}

}
